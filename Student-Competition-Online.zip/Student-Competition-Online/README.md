# 🏆 رقابت دانش‌آموزی آنلاین

پروژه‌ی چندنفره با Node.js، Express و Socket.IO.

## اجرای محلی

```bash
npm install
npm start
```

سپس `http://localhost:3000` را باز کنید.

## انتشار آنلاین

کل محتویات این پوشه را در یک Repository گیت‌هاب آپلود کنید و در Render یک Web Service بسازید.

- Build Command: `npm install`
- Start Command: `npm start`

بعد از Deploy، آدرس HTTPS سرویس را به بازیکن‌ها بدهید. یک نفر اتاق می‌سازد و کد اتاق را برای بقیه می‌فرستد؛ بقیه با همان کد وارد می‌شوند.
